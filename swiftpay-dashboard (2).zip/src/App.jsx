import React, { useState } from 'react';
import LoginPage from './pages/LoginPage';
import PaymentsPage from './pages/PaymentsPage';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  // Simple auth toggle for demo - in production use proper routing (React Router)
  if (!isAuthenticated) {
    return <LoginPage />;
  }

  return <PaymentsPage />;
}

export default App;

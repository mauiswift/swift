import React, { useState } from 'react';
import Sidebar from '../components/Sidebar';
import Header from '../components/Header';
import TransactionRow from '../components/TransactionRow';

const TRANSACTIONS = [
  {
    id: 1,
    amount: '1.00',
    method: 'QRPH P2M',
    reference: 'MP-abad6d6ca2214931af84587e0b67c...',
    createdOn: 'Jul 21 2026, 1:20 pm',
    executedOn: null,
    status: 'Pending',
    iconType: 'qrph',
  },
  {
    id: 2,
    amount: '1.00',
    method: 'SECURITYBANK • QRPH P2M',
    reference: 'MP-41af40d9759c4fcd8adef1509c5a7a...',
    createdOn: 'Jul 21 2026, 1:20 am',
    executedOn: 'Jul 21 2026, 1:21 am',
    status: 'Executed',
    iconType: 'qrph',
  },
  {
    id: 3,
    amount: '100.00',
    method: '-',
    reference: 'E324',
    createdOn: 'Jul 19 2026, 2:49 pm',
    executedOn: null,
    status: 'Expired',
    iconType: 'transfer',
  },
  {
    id: 4,
    amount: '100.00',
    method: 'Maya • Transfer',
    reference: 'E3H6',
    createdOn: 'Jul 16 2026, 10:30 pm',
    executedOn: null,
    status: 'Expired',
    iconType: 'transfer',
  },
  {
    id: 5,
    amount: '100.00',
    method: 'Maya • Transfer',
    reference: 'E3H6',
    createdOn: 'Jul 16 2026, 10:30 pm',
    executedOn: null,
    status: 'Canceled',
    iconType: 'transfer',
  },
  {
    id: 6,
    amount: '100.00',
    method: 'RCBC • Transfer',
    reference: 'E095',
    createdOn: 'Jul 16 2026, 9:30 pm',
    executedOn: null,
    status: 'Expired',
    iconType: 'transfer',
  },
  {
    id: 7,
    amount: '102.00',
    method: 'MAYA • QRPH P2M',
    reference: 'GOYARDTEST20260715220158718CE5',
    createdOn: 'Jul 16 2026, 6:02 am',
    executedOn: 'Jul 16 2026, 6:02 am',
    status: 'Executed',
    iconType: 'qrph',
  },
  {
    id: 8,
    amount: '101.00',
    method: 'MAYA • QRPH P2M',
    reference: 'GOYARDTEST202607152044576A8524',
    createdOn: 'Jul 16 2026, 4:45 am',
    executedOn: 'Jul 16 2026, 4:45 am',
    status: 'Executed',
    iconType: 'qrph',
  },
];

const SummaryCard = ({ label, value }) => (
  <div className="bg-white rounded-xl p-6 border border-gray-100 shadow-sm">
    <p className="text-sm text-gray-500 mb-1">{label}</p>
    <p className="text-3xl font-bold text-gray-900">{value}</p>
  </div>
);

const FilterButton = ({ label, value }) => (
  <button className="flex items-center space-x-2 px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm text-gray-700 hover:bg-gray-50 transition-colors">
    <span>{label}: <span className="font-medium">{value}</span></span>
    <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
    </svg>
  </button>
);

export default function PaymentsPage() {
  const [searchQuery, setSearchQuery] = useState('');

  const totalAmount = TRANSACTIONS.reduce((sum, t) => sum + parseFloat(t.amount), 0);
  const avgAmount = totalAmount / TRANSACTIONS.length;

  const filteredTransactions = TRANSACTIONS.filter((t) =>
    t.reference.toLowerCase().includes(searchQuery.toLowerCase()) ||
    t.method.toLowerCase().includes(searchQuery.toLowerCase()) ||
    t.status.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex h-screen w-full bg-gray-50 font-sans text-gray-800">
      <Sidebar />
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Header />
        <div className="flex-1 overflow-y-auto p-8">
          {/* Filters */}
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center space-x-3">
              <FilterButton label="Created on" value="Last 7 days" />
              <FilterButton label="Status" value="All" />
              <button className="flex items-center space-x-2 px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm text-gray-700 hover:bg-gray-50 transition-colors">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h7" />
                </svg>
                <span>More</span>
              </button>
            </div>
            <div className="relative">
              <svg className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
              <input
                type="text"
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4 py-2 bg-white border border-gray-200 rounded-lg text-sm w-64 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              />
            </div>
          </div>

          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <SummaryCard label="Transactions" value={filteredTransactions.length} />
            <SummaryCard label="Total amount" value={`₱${totalAmount.toFixed(2)}`} />
            <SummaryCard label="Average amount" value={`₱${avgAmount.toFixed(2)}`} />
          </div>

          {/* Transactions History */}
          <div className="bg-white rounded-xl border border-gray-100 shadow-sm">
            <div className="px-6 py-5 border-b border-gray-100">
              <h2 className="text-lg font-semibold text-gray-900">Transactions history</h2>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-100">
                    <th className="text-left px-6 py-3 text-xs font-medium text-gray-400 uppercase tracking-wider">Payment</th>
                    <th className="text-left px-6 py-3 text-xs font-medium text-gray-400 uppercase tracking-wider">Reference No</th>
                    <th className="text-left px-6 py-3 text-xs font-medium text-gray-400 uppercase tracking-wider">Date</th>
                    <th className="text-left px-6 py-3 text-xs font-medium text-gray-400 uppercase tracking-wider">Payment Status</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredTransactions.map((transaction) => (
                    <TransactionRow key={transaction.id} transaction={transaction} />
                  ))}
                </tbody>
              </table>
            </div>
            {filteredTransactions.length === 0 && (
              <div className="px-6 py-12 text-center text-gray-500">
                No transactions found matching your search.
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}

import React from 'react';

const menuItems = [
  { section: 'Menu', items: [
    { label: 'Home', icon: 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4' },
    { label: 'Approvals', icon: 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z' },
  ]},
  { section: 'Transactions', items: [
    { label: 'Payments', icon: 'M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z', active: true },
    { label: 'Payment Links', icon: 'M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1' },
    { label: 'Disbursements', icon: 'M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4' },
  ]},
  { section: 'Insights', items: [
    { label: 'Reports', icon: 'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z' },
  ]},
];

const systemItems = [
  { label: 'Settings', icon: 'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z M15 12a3 3 0 11-6 0 3 3 0 016 0z' },
  { label: 'Logout', icon: 'M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1' },
];

const Icon = ({ path }) => (
  <svg className="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={path} />
  </svg>
);

export default function Sidebar() {
  return (
    <aside className="w-64 bg-gray-900 text-gray-400 flex flex-col flex-shrink-0 h-screen">
      <div className="h-16 flex items-center px-6">
        <div className="w-8 h-8 bg-white rounded flex items-center justify-center mr-3">
          <svg className="w-5 h-5 text-gray-900" fill="currentColor" viewBox="0 0 20 20">
            <path d="M10 2a8 8 0 100 16 8 8 0 000-16z" />
          </svg>
        </div>
      </div>

      <nav className="flex-1 px-3 space-y-1 mt-2 overflow-y-auto">
        {menuItems.map((group) => (
          <div key={group.section}>
            <div className="text-xs font-semibold uppercase tracking-wider text-gray-500 px-3 mb-2 mt-6">
              {group.section}
            </div>
            {group.items.map((item) => (
              <a
                key={item.label}
                href="#"
                className={`flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                  item.active
                    ? 'bg-gray-800 text-orange-400'
                    : 'hover:bg-gray-800 hover:text-white'
                }`}
              >
                <Icon path={item.icon} />
                {item.label}
              </a>
            ))}
          </div>
        ))}

        <div className="text-xs font-semibold uppercase tracking-wider text-gray-500 px-3 mb-2 mt-6">
          System
        </div>
        <div className="flex items-center justify-between px-3 py-2">
          <div className="flex items-center">
            <svg className="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
            </svg>
            <span className="text-sm font-medium">Test mode</span>
          </div>
          <button className="relative inline-flex h-5 w-9 items-center rounded-full bg-green-500 transition-colors">
            <span className="inline-block h-3 w-3 transform translate-x-5 rounded-full bg-white transition-transform" />
          </button>
        </div>
        {systemItems.map((item) => (
          <a
            key={item.label}
            href="#"
            className="flex items-center px-3 py-2 text-sm font-medium rounded-md hover:bg-gray-800 hover:text-white transition-colors"
          >
            <Icon path={item.icon} />
            {item.label}
          </a>
        ))}
      </nav>

      <div className="px-6 py-4 text-xs text-gray-500 border-t border-gray-800">
        <div className="flex items-center">
          <span>Powered by</span>
          <span className="ml-1 font-semibold text-gray-300">SwiftPay</span>
        </div>
      </div>
    </aside>
  );
}

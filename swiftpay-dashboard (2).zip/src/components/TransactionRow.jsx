import React from 'react';
import PaymentIcon from './PaymentIcon';
import StatusBadge from './StatusBadge';

export default function TransactionRow({ transaction }) {
  const { amount, method, reference, createdOn, executedOn, status, iconType } = transaction;

  return (
    <tr className="hover:bg-gray-50 transition-colors border-b border-gray-50 last:border-b-0">
      <td className="px-6 py-4">
        <div className="flex items-center">
          <PaymentIcon type={iconType} />
          <div>
            <p className="text-sm font-semibold text-gray-900">₱{amount}</p>
            <p className="text-xs text-gray-500">{method}</p>
          </div>
        </div>
      </td>
      <td className="px-6 py-4">
        <div className="flex items-center space-x-2">
          <span className="text-sm text-gray-600 font-mono truncate max-w-xs">{reference}</span>
          <button
            className="text-gray-400 hover:text-gray-600 flex-shrink-0"
            onClick={() => navigator.clipboard.writeText(reference)}
            title="Copy reference"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
            </svg>
          </button>
        </div>
      </td>
      <td className="px-6 py-4">
        <div className="text-sm text-gray-600">
          <p>Created on: {createdOn}</p>
          <p className="text-gray-400">Executed on: {executedOn || '-'}</p>
        </div>
      </td>
      <td className="px-6 py-4">
        <StatusBadge status={status} />
      </td>
    </tr>
  );
}

import React from 'react';

const STATUS_STYLES = {
  Pending: { bg: 'bg-blue-50', text: 'text-blue-600', dot: 'bg-blue-500' },
  Executed: { bg: 'bg-emerald-50', text: 'text-emerald-600', dot: 'bg-emerald-500' },
  Expired: { bg: 'bg-gray-100', text: 'text-gray-600', dot: 'bg-gray-500' },
  Canceled: { bg: 'bg-indigo-50', text: 'text-indigo-600', dot: 'bg-indigo-500' },
};

export default function StatusBadge({ status }) {
  const style = STATUS_STYLES[status] || STATUS_STYLES.Expired;
  return (
    <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${style.bg} ${style.text}`}>
      <span className={`w-1.5 h-1.5 ${style.dot} rounded-full mr-2`} />
      {status}
    </span>
  );
}

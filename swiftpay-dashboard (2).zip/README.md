# SwiftPay Merchant Portal

A React-based merchant portal matching the SwiftPay UI, including authentication and payments dashboard.

## Features

### Login Page
- Clean centered authentication form
- Username & password inputs with show/hide toggle
- Forgot password link
- Terms & conditions acknowledgment
- "Contact us" for new accounts
- Loading state on submit

### Payments Dashboard
- Dark sidebar navigation with active state highlighting
- Summary cards (Transactions, Total amount, Average amount)
- Searchable transactions history table
- Status badges (Pending, Executed, Expired, Canceled)
- Copy-to-clipboard for reference numbers
- Responsive layout

## Getting Started

```bash
# Install dependencies
npm install

# Run dev server
npm run dev

# Build for production
npm run build
```

## Project Structure

```
src/
├── components/
│   ├── Sidebar.jsx
│   ├── Header.jsx
│   ├── StatusBadge.jsx
│   ├── PaymentIcon.jsx
│   └── TransactionRow.jsx
├── pages/
│   ├── LoginPage.jsx
│   └── PaymentsPage.jsx
├── App.jsx
├── main.jsx
└── index.css
```

## Tech Stack

- React 18
- Vite
- Tailwind CSS
